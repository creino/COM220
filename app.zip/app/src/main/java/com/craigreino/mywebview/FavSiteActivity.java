package com.craigreino.mywebview;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class FavSiteActivity extends AppCompatActivity {

    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fav_site);

        webView = findViewById(R.id.webview);
        webView.setWebViewClient(new WebViewClient()); // Declare webview default viewer
        webView.loadUrl(getString(R.string.favorite_site));
    }
}
